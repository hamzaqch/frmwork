# PAI on GitHub Copilot — Deployment Guide

> Code-focused PAI port for VSCode + GitHub Copilot on Windows. Single-project deployment.

## What's in this bundle

```
.github/
├── copilot-instructions.md       # Global routing (always loaded)
├── instructions/                 # Scoped instructions (applyTo globs)
├── prompts/                      # Slash commands
├── agents/                       # Custom agent personas (.agent.md)
├── algorithm/                    # 7-phase doctrine + ISC granularity rules
├── skills/                       # Skill bundles (Algorithm/ISA/Agents/Knowledge/...)
├── hooks/hooks.json              # Lifecycle hook registration
└── scripts/                      # Python hook implementations

.vscode/
├── mcp.json                      # MCP server registration (Databricks + GitHub)
└── mcp-servers/
    └── databricks_mcp.py         # Custom Databricks MCP (SELECT-only)

MEMORY/
├── WORK/                         # Active task ISAs
│   └── example/ISA.md            # Reference example
├── KNOWLEDGE/                    # Typed entity graph (Ideas/People/Companies/Research)
└── LEARNING/                     # Session learnings (gitignored)

probe/                            # Pre-deployment hook contract verification
├── probe_hook.py
└── PROBE_README.md
```

## Prerequisites

- Windows + VSCode + GitHub Copilot extension (a version that supports Preview lifecycle hooks; verify with the probe — see Phase 0)
- Python 3.10+ via the `py` launcher (`py -3 --version`). The launcher ships with python.org installers and is more reliable on Windows than `python` on PATH. **If `py` is not installed**, edit `.github/hooks/hooks.json` and `.vscode/mcp.json` to use `"command": "python"` and drop the `"-3"` arg.
- `databricks` CLI on PATH and authenticated (`databricks auth login`)
- `python -m pip install "mcp[cli]"` (for the Databricks MCP — Phase 3)

## Deployment phases

### Phase 0 — Verify hook contract (5-10 min)

Before relying on Phase 2 hooks as load-bearing enforcement, capture Copilot's actual hook stdin/stdout contract.

```powershell
# Copy the probe into your repo's .github/scripts/
Copy-Item probe\probe_hook.py .github\scripts\probe_hook.py -Force

# Temporarily add probe entries to .github/hooks/hooks.json (see probe/PROBE_README.md)
# Reload VSCode, run 5 representative chat actions, read probe/probe-log.jsonl.
```

Compare logged stdin against assumptions documented in `OPEN_QUESTIONS.md`. If the contract differs, surface samples back to whoever generated this bundle for adjustments to `security_pipeline.py` / `isa_sync.py`.

### Phase 1 — Instructions, agents, prompts (deployable in <30 min)

```powershell
# From your work repo's root:
xcopy /E /I /Y <bundle>\.github .github
xcopy /E /I /Y <bundle>\MEMORY MEMORY
```

Reload VSCode (`Ctrl+Shift+P` → "Developer: Reload Window"). Test:

```
@principal hello
/algo build a thing
```

You should see:
- `principal.agent.md` voice in the response
- `MEMORY/WORK/build-a-thing/` directory created
- An `ISA.md` file inside, frontmatter populated

### Phase 2 — Lifecycle hooks (15 min)

Hooks already shipped in Phase 1 (`.github/hooks/hooks.json` + `.github/scripts/*.py`). They activate on next VSCode window reload.

Verify:
1. Edit any `.md` file under `MEMORY/WORK/` → check `MEMORY/WORK/work.json` updates with the slug + phase.
2. Try `git push --force` in the integrated terminal → should be blocked with `[PAI SECURITY] BLOCKED: destructive force-push`.
3. Try `databricks fs rm --recursive ...` → should be blocked.

If a hook fails: check `MEMORY/LEARNING/hook-log.jsonl` for the script's log entries.

### Phase 3 — Databricks MCP (15-30 min)

```powershell
python -m pip install -r .vscode\mcp-servers\databricks_mcp.requirements.txt
```

Standalone test:

```powershell
python .vscode\mcp-servers\databricks_mcp.py
```

(should hang waiting for stdio JSON-RPC; Ctrl+C to exit)

Reload VSCode. Test:

```
@data-analyst list catalogs
```

You should see the agent invoke `databricks/list_catalogs` and return Unity Catalog catalog names.

### Phase 4 — Knowledge (already shipped)

Knowledge directory + skill bundle already in Phase 1 bundle. Test:

```
/knowledge-add
```

Run through the 5-question interview. New note appears under `MEMORY/KNOWLEDGE/<type>/<slug>.md`.

### Phase 5 — Iteration

After 1-2 weeks of use:

- Audit which agents/skills get invoked → drop unused (Bitter Pill discipline).
- Promote stable patterns into a reusable framework repo.
- Decide whether to add observability (currently out of scope).

## .gitignore additions

Add these to your repo's `.gitignore`:

```
MEMORY/WORK/work.json
MEMORY/WORK/*/outputs/
MEMORY/LEARNING/
probe/probe-log.jsonl
.github/scripts/probe_hook.py
```

Keep `MEMORY/WORK/*/ISA.md` and `MEMORY/KNOWLEDGE/**/*.md` committed — they are project documentation.

## Dynamic agent creation

User says: *"I need an agent that audits SQL migrations for safety."*

```
/create-pai-agent
```

The `scaffold-agent` runs a 5-question interview (one question per turn), then writes `.github/agents/sql-migration-auditor.agent.md` and updates `principal.agent.md` `handoffs:` list. Available immediately as `@sql-migration-auditor`.

## Open questions

See `OPEN_QUESTIONS.md` for assumptions you should validate in your environment before relying on the bundle in production.

## Troubleshooting

| Symptom | Likely cause |
|---------|--------------|
| Agents don't load | VSCode not reloaded after copying files |
| `/algo` not recognized | `prompts/` directory missing or wrong path |
| Hook blocks legitimate work | Read `MEMORY/LEARNING/hook-log.jsonl` for the deny pattern; refine `security_pipeline.py` |
| Databricks MCP errors immediately | `mcp[cli]` not installed or `databricks` CLI not authenticated |
| `work.json` shows wrong phase | Check ISA frontmatter `phase:` field — hook reads it verbatim |
