---
applyTo: "MEMORY/KNOWLEDGE/**/*.md"
---

# Knowledge Note Format

Every note under `MEMORY/KNOWLEDGE/` is a typed entity with mandatory cross-links.

## Frontmatter contract

```yaml
---
title: <human title>
type: idea | person | company | research
created: 2026-MM-DD
updated: 2026-MM-DD
related:
  supports: [<slug>]
  contradicts: [<slug>]
  extends: [<slug>]
  part-of: [<slug>]
  instance-of: [<slug>]
  caused-by: [<slug>]
  preceded-by: [<slug>]
  related: [<slug>]
tags: [<keyword>, ...]
---
```

At least one entry across all eight `related:` keys is required. Orphan notes are rejected.

## Body structure

Three sections, in order:

1. `## Summary` — 1-3 sentences capturing the essence.
2. `## Detail` — the substance; quote primary sources where applicable.
3. `## Cross-links` — narrative explanation of the typed links above (why they're related, not just that they are).

## Wikilinks

Use `[[slug]]` syntax for in-body references to other knowledge notes. The Search workflow uses these as the third pass after lexical and frontmatter matching.

## File naming

`<slug>.md` where slug is kebab-case, ASCII only. The slug must match the filename without extension.
