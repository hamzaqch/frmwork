---
applyTo: "**"
---

# Windows Shell Conventions

This repository runs on Windows. Always:

- **Shell:** PowerShell 7+. Never `bash`, `sh`, `zsh`.
- **Command chaining:** Use `;` not `&&`. PowerShell evaluates each statement independently.
- **Path separator:** Backslash (`\`). When inside JSON or YAML, escape as `\\`.
- **Quote paths with spaces:** `"C:\Program Files\…"`.
- **Error suppression:** `2>$null` not `2>/dev/null`.
- **Environment vars:** `$env:VAR_NAME` not `$VAR_NAME`.
- **Find files:** `Get-ChildItem -Recurse -Filter "*.py"` not `find . -name "*.py"`.
- **Grep equivalent:** `Select-String -Pattern "..." -Path *.md` or `rg` (if installed).
- **Make directory:** `New-Item -ItemType Directory -Path "..." -Force` not `mkdir -p`.

## Python invocation

- Use `python` (Windows resolves it via PATH or the launcher). Avoid `python3` — not always present.
- Pip: `python -m pip install ...` not bare `pip install`.
- Virtual env: `python -m venv .venv` then `.\.venv\Scripts\Activate.ps1`.

## Hook scripts

All `.github/scripts/*.py` files run via `python <script>.py` per `hooks.json`. Never assume `/usr/bin/python` shebang works on Windows; the JSON command field is what matters.

## Forbidden tokens in any code or instruction

- `bash`, `sh`, `/bin/`, `/usr/`, `${HOME}`, `~/`, `mkdir -p`, `rm -rf`, `&&`, `||` (POSIX-style)
