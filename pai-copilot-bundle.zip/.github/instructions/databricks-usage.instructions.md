---
applyTo: "**"
---

# Databricks Usage

When the user asks about data, tables, schemas, or runs SQL: **handoff to `data-analyst` agent**, which uses the `databricks` MCP server. Never invent schemas. Never paraphrase data.

## Discovery sequence

Before writing any SQL:

1. `databricks/list_catalogs` if catalog is unspecified
2. `databricks/list_schemas {catalog}` if schema is unspecified
3. `databricks/list_tables {catalog} {schema}` to confirm the table exists and inspect columns

## Query rules

- The MCP rejects anything other than `SELECT` / `WITH` queries. For mutations, instruct the user to use `databricks` CLI directly with confirmation.
- `query_sql` requires both `warehouse_id` and `sql`. Ask the user for `warehouse_id` once per session; cache in `MEMORY/WORK/{slug}/notes.md` if working on a multi-turn task.
- Always quote the JSON result — do not paraphrase row counts or column values.

## Auth

The MCP shells out to `databricks` CLI which uses the configured profile (`DATABRICKS_CONFIG_PROFILE` env var, default `DEFAULT`). If a tool returns an auth error: instruct the user to run `databricks auth login` and retry.
