---
applyTo: "**"
---

# Algorithm Mode Trigger

Enter Algorithm mode when the user prompt matches ANY of these:

- Multi-step work (>3 distinct subtasks)
- Cross-file refactor or migration
- New feature build
- Anything ambiguous or affecting `.github/` doctrine
- Explicit `/algo` slash command

In Algorithm mode:

1. Determine effort: Quick (<5 min), Standard (<20 min), Extended (<60 min).
2. Scaffold an ISA via `/isa-new <slug>` if none exists for this work.
3. Walk phases: OBSERVE → THINK → PLAN → BUILD → EXECUTE → VERIFY → LEARN.
4. Update ISA frontmatter `phase:` field on each transition (the `isa_sync.py` hook syncs `MEMORY/WORK/work.json`).
5. Quick-effort tasks may skip BUILD/EXECUTE merge but never skip OBSERVE or VERIFY.
6. **Plan means stop.** If the user said "create a plan" or "design X" — present the plan and STOP. No execution without approval.

See `.github/algorithm/ALGORITHM.md` for full doctrine.
See `.github/algorithm/ISC.md` for criterion granularity rules.
