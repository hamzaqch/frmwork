---
applyTo: "**"
---

# Memory Routing — where things go

| What | Where | Lifetime |
|------|-------|----------|
| Active task ISA | `MEMORY/WORK/{slug}/ISA.md` | Until phase: complete |
| Per-task scratchpad | `MEMORY/WORK/{slug}/notes.md` | Until phase: complete |
| Per-task generated outputs | `MEMORY/WORK/{slug}/outputs/` (gitignored) | Local only |
| Active task registry | `MEMORY/WORK/work.json` (auto-written by hook) | Auto-managed |
| Reusable knowledge — Ideas | `MEMORY/KNOWLEDGE/Ideas/{slug}.md` | Permanent |
| Reusable knowledge — People | `MEMORY/KNOWLEDGE/People/{slug}.md` | Permanent |
| Reusable knowledge — Companies | `MEMORY/KNOWLEDGE/Companies/{slug}.md` | Permanent |
| Reusable knowledge — Research | `MEMORY/KNOWLEDGE/Research/{slug}.md` | Permanent |
| Session learnings (auto-append) | `MEMORY/LEARNING/sessions.jsonl` (gitignored) | Local |

## Knowledge note frontmatter

Every `MEMORY/KNOWLEDGE/*/*.md` requires:

```yaml
---
title: <human title>
type: idea | person | company | research
created: <ISO date>
updated: <ISO date>
related:
  - supports: [<slug>]
  - contradicts: [<slug>]
  - extends: [<slug>]
  - part-of: [<slug>]
  - instance-of: [<slug>]
  - caused-by: [<slug>]
  - preceded-by: [<slug>]
  - related: [<slug>]
tags: [<keyword>, ...]
---
```

`related:` is required (any of the 8 link types). At least one cross-link per note — orphan notes are not allowed.

## Routing rules

- "I want to remember that X" → KNOWLEDGE (typed by what X is)
- "Track that I'm working on X" → WORK (with ISA)
- "Capture this transient session note" → LEARNING (auto-append on Stop)
