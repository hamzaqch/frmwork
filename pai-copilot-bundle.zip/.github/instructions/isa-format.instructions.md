---
applyTo: "MEMORY/WORK/**/ISA.md"
---

# ISA Format — Twelve Sections

Every `ISA.md` MUST have this frontmatter:

```yaml
---
slug: <kebab-case>
title: <human title>
phase: OBSERVE | THINK | PLAN | BUILD | EXECUTE | VERIFY | LEARN | COMPLETE
effort: quick | standard | extended
progress: M/N
created: <ISO 8601 UTC>
updated: <ISO 8601 UTC>
---
```

Body sections in this exact order (empty sections are dropped, never left empty):

1. `## Problem` — what is broken or missing right now.
2. `## Vision` — what euphoric surprise looks like; experiential intent.
3. `## Out of Scope` — anti-vision; what is *not* included.
4. `## Principles` — substrate-independent truths the work must respect.
5. `## Constraints` — immovable architectural mandates.
6. `## Goal` — hard-to-vary spine; 1-3 sentences naming verifiable done.
7. `## Criteria` — atomic ISCs (one binary tool probe each), including derived `Anti:` and `Antecedent:` prefixes.
8. `## Test Strategy` — per-ISC verification approach: `isc | type | check | threshold | tool`.
9. `## Features` — work breakdown: `name | satisfies | depends_on | parallelizable`.
10. `## Decisions` — timestamped decision log (incl. dead ends, `refined:` prefix for evolutions).
11. `## Changelog` — conjecture / refuted-by / learned / criterion-now entries.
12. `## Verification` — evidence per ISC; one line per `[x]`.

## Required sections per effort

| Effort | Required |
|--------|----------|
| Quick | Goal, Criteria |
| Standard | + Problem, Test Strategy |
| Extended | + Vision, Out of Scope, Constraints, Features |

## ID-stability rule

ISC IDs never re-number on edit. Splits become `ISC-N.M` (parent preserved). Drops become tombstones (`[ ] ISC-N: [DROPPED — see Decisions]`).

## Anti-criteria reminder

Before completing OBSERVE, ask: have I included at least one `Anti:` ISC? What MUST NOT happen for this work to count as done?
