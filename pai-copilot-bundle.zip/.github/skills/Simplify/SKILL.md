# Simplify Skill

Reviews recently changed code for simplification opportunities while preserving all functionality.

## When to use

- After completing a coding task, before claiming done
- When the user says "simplify", "review", "clean up"
- Pre-PR check

## Look for

- **Redundancy** — repeated logic appearing 3+ times that can be extracted
- **Premature abstractions** — interfaces/factories with one implementation
- **Dead code** — unused exports, unreachable branches
- **Over-engineering** — error handling for impossible cases
- **Comment rot** — comments describing WHAT instead of WHY, comments referencing past task IDs
- **Backwards-compat shims** — code paths nobody calls anymore

## Output

```
SIMPLIFY:
  - <file>:<line> — <change> — <why safe>
KEEP AS-IS:
  - <file>:<line> — <looked simplifiable but is load-bearing because Y>
```

## Hard rule

Never propose a simplification that changes behavior. Style and structure only.
