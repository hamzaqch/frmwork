# Research Skill

External documentation lookup. Reads primary sources before opining.

## When to use

- Library API question
- Unfamiliar error message
- "What's the current best practice for..."
- Comparative ("X vs Y")

## Method

1. Identify source of truth (official docs, RFC, repo README).
2. Read the relevant section. Quote it.
3. For comparative questions, read both sides and produce side-by-side.
4. Summarize in 5-15 bullets with citations.
5. If finding contradicts user's stated assumption, surface explicitly.
6. If reusable, append to `MEMORY/KNOWLEDGE/Research/{slug}.md` (with cross-links).

## Output

```
QUESTION: <one sentence>
SOURCES:
  - <url>
FINDINGS:
  - <bullet> [src: <url>]
RECOMMENDATION: <one sentence>
```

## Hard rules

- Never paraphrase a source as if it were your own knowledge. Quote and cite.
- Never claim a feature exists without a doc reference.
- 404 / paywall → say so. Never invent a substitute.
