# FirstPrinciples Skill

Physics-based reasoning. Deconstruct → Challenge → Reconstruct.

## When to use

- Stuck on a problem framed by analogy ("we always do it this way")
- Architectural decision with inherited assumptions
- Before RedTeam — challenge the constraints, then attack the survivors

## 3-step framework

### 1. Deconstruct
"What is this actually made of?"
Break problem into constituent parts and fundamental truths.

### 2. Challenge
For each part, classify:
- **Hard** — physics/reality (cannot change)
- **Soft** — policy/choice (can change)
- **Assumption** — unvalidated belief (probably can change)

### 3. Reconstruct
"Given only the hard constraints, what's optimal?"
Build the solution from fundamentals, ignoring inherited form.

## Output

```
TARGET: <problem>
CONSTITUENT PARTS:
  - <part>: <actual cost / role>
CONSTRAINT CLASSIFICATION:
  | Constraint | Type | Evidence | If removed? |
RECONSTRUCTED SOLUTION: <built from hard constraints only>
KEY INSIGHT: <one sentence — what assumption was limiting us?>
```

## Hard rule

Every assumption is guilty until proven innocent. "Because that's how we've always done it" is not evidence.
