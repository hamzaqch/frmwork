# Knowledge Add Workflow

Create a typed knowledge note with mandatory cross-links.

## Inputs

- `type` (idea | person | company | research)
- `title`
- `slug` (kebab-case, ASCII)
- `summary` (1-3 sentences)
- `detail` (the substance; quotes from primary sources where applicable)

## Steps

1. Determine target directory:
   - `idea` → `MEMORY/KNOWLEDGE/Ideas/`
   - `person` → `MEMORY/KNOWLEDGE/People/`
   - `company` → `MEMORY/KNOWLEDGE/Companies/`
   - `research` → `MEMORY/KNOWLEDGE/Research/`
2. Run Knowledge Search with the title/summary keywords to find candidate cross-links.
3. Ask user: "What does this connect to? Candidates: [list]". User picks at least one.
4. Write `<dir>/<slug>.md` with frontmatter (per `knowledge-format.instructions.md`) and 3-section body:
   - `## Summary`
   - `## Detail`
   - `## Cross-links` (narrative explanation of the typed `related:` entries)
5. For each `related:` entry, ask user whether to make the link bidirectional (edit the linked note's `related:`).
6. Confirm: `Knowledge note created: <path>. Cross-links: <count>.`

## Hard rules

- No orphan notes. Reject if `related:` is empty after Step 3.
- Never invent a slug. The frontmatter `slug` must match the filename.
