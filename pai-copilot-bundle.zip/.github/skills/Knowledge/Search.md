# Knowledge Search Workflow

3-pass lookup across `MEMORY/KNOWLEDGE/`.

## Pass 1 — Lexical

`Select-String -Pattern "{query}" -Path MEMORY/KNOWLEDGE/**/*.md` (PowerShell) or `rg "{query}" MEMORY/KNOWLEDGE/` (if `rg` available).

Capture: file paths, matching line numbers, surrounding context.

## Pass 2 — Frontmatter

For each `.md` under `MEMORY/KNOWLEDGE/`, parse frontmatter and match `{query}` against:
- `title`
- `tags` (array)
- `type`

## Pass 3 — Wikilinks

Find notes that contain `[[query]]` or `[[query.md]]`. Also find notes that the `{query}.md` itself references.

## Synthesis

Combine results, dedupe by path, rank by:

1. Title exact match (10 pts)
2. Tag match (5 pts)
3. Body lexical match (1 pt per occurrence, capped at 5)
4. Wikilink-graph 1-hop proximity (3 pts)

Output top 10. If 0 hits, surface query terms used and suggest tag candidates from frontmatter.
