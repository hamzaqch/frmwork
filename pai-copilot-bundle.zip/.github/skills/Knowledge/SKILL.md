# Knowledge Skill

CRUD over `MEMORY/KNOWLEDGE/` — typed entity graph (Ideas, People, Companies, Research).

## When to use

- "I want to remember X" / "save this for later" → Add workflow
- "What do we know about Y?" → Search workflow
- "How does X relate to Y?" → graph traversal via wikilinks

## Workflows

- `Add.md` — create a new note with mandatory cross-links
- `Search.md` — 3-pass lookup (lexical, frontmatter, wikilinks)

## Format

See `.github/instructions/knowledge-format.instructions.md`.

## Hard rules

- Every note has frontmatter: `title`, `type`, `created`, `updated`, `related`, `tags`.
- Every note has at least one `related:` entry — orphan notes are rejected.
- File names match slugs (kebab-case, ASCII).
