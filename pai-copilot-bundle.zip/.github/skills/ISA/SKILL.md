# ISA Skill

ISA = Ideal State Articulation. The single source of truth per task: ideal state, test harness, build verification, done condition, system of record — all in one Markdown file.

## When to use

- Starting any multi-step task → Scaffold workflow
- Task evolves with new ISCs → Append workflow
- Task complete and ready to merge with parent project → Reconcile workflow

## Workflows

- `Scaffold.md` — create a new ISA at `MEMORY/WORK/{slug}/ISA.md`
- `Append.md` — add criteria, decisions, verification entries (append-only)
- `Reconcile.md` — merge ephemeral feature ISA back into the master

## Format

See `.github/instructions/isa-format.instructions.md` for the twelve-section spec and frontmatter contract.

## Hard rules

- ISC IDs never re-number on edit. Splits become `ISC-N.M`. Drops become tombstones.
- Frontmatter `phase:` + `progress:` are the source of truth — the `isa_sync.py` PostToolUse hook reads these.
- Every `[x]` requires a matching entry in `## Verification`.
