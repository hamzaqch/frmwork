# ISA Append Workflow

Append-only edits to `MEMORY/WORK/{slug}/ISA.md` — preserves canonical format.

## Append types

| Type | Section | Format |
|------|---------|--------|
| criterion | `## Criteria` | `- [ ] ISC-N: <text>` (next sequential N, or N.M if splitting) |
| decision | `## Decisions` | `- {ISO timestamp} — {text}` |
| verification | `## Verification` | `ISC-N: {probe} — {evidence}` |
| changelog | `## Changelog` | conjectured / refuted_by / learned / criterion_now (all four required) |

## Hard rules

- Never re-number existing ISCs.
- Never delete a criterion. Strike-through with `~~text~~` or mark `[DROPPED]`.
- Changelog entries require all four fields. Partial entries are rejected.
