# ISA Scaffold Workflow

Create a new ISA at `MEMORY/WORK/{slug}/ISA.md`.

## Inputs

- `slug` (kebab-case)
- `title` (human-readable)
- `effort` (quick | standard | extended)
- `prompt` (the user's original request, used to seed sections)

## Steps

1. Create directory `MEMORY/WORK/{slug}/`.
2. Generate frontmatter:
   ```yaml
   ---
   slug: {slug}
   title: {title}
   phase: OBSERVE
   effort: {effort}
   progress: 0/0
   created: {ISO 8601 UTC}
   updated: {ISO 8601 UTC}
   ---
   ```
3. Generate body sections based on effort:
   - **Quick:** `## Goal`, `## Criteria`
   - **Standard:** + `## Problem`, `## Test Strategy`
   - **Extended:** + `## Vision`, `## Out of Scope`, `## Principles`, `## Constraints`, `## Features`, `## Decisions`
4. Seed `## Goal` from the user's prompt (1-3 sentences, hard-to-vary).
5. Seed `## Criteria` with at least one ISC and one `Anti:` ISC.
6. Write `MEMORY/WORK/{slug}/ISA.md` via `editFiles`.

## Output

```
ISA scaffolded: MEMORY/WORK/{slug}/ISA.md
phase: OBSERVE
effort: {effort}
ISCs: {N} (including {anti_count} Anti)
```
