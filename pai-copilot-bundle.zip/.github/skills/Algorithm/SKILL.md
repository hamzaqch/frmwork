# Algorithm Skill

The 7-phase verifiable iteration framework: OBSERVE → THINK → PLAN → BUILD → EXECUTE → VERIFY → LEARN.

## When to use

- Multi-step work (>3 distinct subtasks)
- Cross-file changes
- Anything ambiguous or affecting `.github/` doctrine
- Explicit `/algo` slash command

## Core idea

Every run transitions from **Current State** to **Ideal State**. ISC criteria are the testable claims that decompose "done." Verification is the proof each claim was met.

## Doctrine

See `.github/algorithm/ALGORITHM.md` for the full doctrine and `.github/algorithm/ISC.md` for criterion granularity rules.

## Output format

Each phase emits a header (`━━━ 👁️ OBSERVE ━━━ 1/7` etc.) and a phase-specific body. The final phase always closes with a SUMMARY block.

## Hard rules

- "Plan means stop" — present at PLAN and wait for approval if user said "plan" or "design".
- Every `[ ] → [x]` ISC transition needs tool evidence in `## Verification`.
- ID-stability — never re-number ISCs on edit.
- Re-read check at VERIFY — re-read the user's original message and confirm every explicit ask shipped.
