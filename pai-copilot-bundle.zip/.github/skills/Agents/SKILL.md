# Agents Skill

Compose, dispatch, and chain agents. Each `.agent.md` is a persona with frontmatter + behavioral spec.

## When to use

- User wants a recurring task as a named agent → `/create-pai-agent` (uses `scaffold-agent`)
- Specialist work needed → `/handoff <agent>` to a named agent
- Multi-agent flow (engineer → reviewer → engineer) → declare `handoffs:` in agent frontmatter

## Frontmatter contract

```yaml
---
name: <kebab-case>
description: <one sentence>
model: claude-opus-4.6
tools: [<tool>, ...]   # codebase, editFiles, terminal, runCommands, githubRepo, mcp:<server>
handoffs: [<agent>, ...]
---
```

## Body structure

Every agent file MUST include these sections:

- **Identity** — 1 paragraph
- **When to invoke** — trigger phrases
- **Workflow** — numbered steps
- **Hard rules** — at least 2 deny rules
- **Output format** — concrete template
- **Voice** — tone description

See `.github/agents/_template.agent.md` for the canonical template.

## Hard rules

- Never create an agent without going through `/create-pai-agent` (guarantees consistency + handoff registration).
- Never write hard rules into an agent that block its stated purpose.
- Agents created by `scaffold-agent` MUST be appended to `principal.agent.md` `handoffs:` list — otherwise unreachable.
