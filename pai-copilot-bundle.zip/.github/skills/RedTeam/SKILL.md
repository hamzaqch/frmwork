# RedTeam Skill

Adversarial stress-test on ideas, plans, and arguments — not on systems or infrastructure.

## When to use

- "What could go wrong with this plan?"
- "Stress test this idea"
- Before committing to a high-stakes decision
- After Architect produces a plan, before Engineer builds

## Method

1. **Decompose** the target into atomic claims (8-24).
2. **Attack** each claim from the perspectives of: skeptical engineer, paranoid security reviewer, end-user, regulator.
3. **Synthesize** findings ranked by severity (CRITICAL / HIGH / MEDIUM / LOW).
4. **Steelman** the strongest objection — what is the actual best version of the criticism?
5. **Counter-argue** — for each finding, propose a remediation.

## Output

```
TARGET: <claim>
ATTACK SURFACES:
  - <surface 1>: <attack> — severity: <level> — remediation: <action>
  ...
STRONGEST OBJECTION: <one sentence>
RECOMMENDED MITIGATIONS: <ranked list>
```

## Hard rule

The goal is to STRENGTHEN the target, not destroy it. Every finding ships with a remediation path.
