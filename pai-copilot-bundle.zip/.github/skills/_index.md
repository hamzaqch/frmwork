# Skill Index

Skills are bundles of instructions for specific domains. Each skill has a `SKILL.md` (the philosophy + when-to-use) and zero or more workflow files.

| Skill | Trigger phrases | Path |
|-------|-----------------|------|
| Algorithm | "algo", "algorithm mode", "multi-step task" | `.github/skills/Algorithm/SKILL.md` |
| ISA | "scaffold ISA", "new ISA", "update ISA" | `.github/skills/ISA/SKILL.md` |
| Agents | "create agent", "compose agent", "agent factory" | `.github/skills/Agents/SKILL.md` |
| Knowledge | "knowledge note", "search knowledge", "what do we know about" | `.github/skills/Knowledge/SKILL.md` |
| Simplify | "simplify", "review", "clean up" | `.github/skills/Simplify/SKILL.md` |
| RedTeam | "red team", "stress test", "what could go wrong" | `.github/skills/RedTeam/SKILL.md` |
| FirstPrinciples | "first principles", "challenge assumptions", "why" | `.github/skills/FirstPrinciples/SKILL.md` |
| Research | "research", "look up", "find sources" | `.github/skills/Research/SKILL.md` |

When the user's request matches a trigger phrase, read the corresponding `SKILL.md` and follow its instructions.
