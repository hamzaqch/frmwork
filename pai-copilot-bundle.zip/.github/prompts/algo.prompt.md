---
mode: agent
description: Enter Algorithm mode for multi-step work. Scaffolds an ISA and walks the 7 phases.
---

You are now in **Algorithm mode**.

The user's task is: ${input:task:What are we working on?}

## Step 1 — OBSERVE

Restate the intent in one sentence. Then determine effort:

- **Quick** (<5 min) — single-domain, 1-3 ISCs
- **Standard** (<20 min) — multi-step single-feature, 4-12 ISCs
- **Extended** (<60 min) — multi-file substantial, 12+ ISCs

## Step 2 — Scaffold ISA

Pick a kebab-case `slug` from the task. Run `/isa-new ${slug}` (or write the file directly via `editFiles`).

The ISA path will be `MEMORY/WORK/${slug}/ISA.md`.

Populate at minimum (per effort):

- Goal (always)
- Criteria (always)
- Problem, Test Strategy (Standard+)
- Vision, Out of Scope, Constraints, Features (Extended)

## Step 3 — Walk phases

Update frontmatter `phase:` at each transition. The `isa_sync.py` PostToolUse hook syncs `MEMORY/WORK/work.json`.

Phase order: OBSERVE → THINK → PLAN → BUILD → EXECUTE → VERIFY → LEARN → COMPLETE.

## Step 4 — Verify and stop

After every ISC is `[x]` with evidence, run the re-read check: re-read the user's original task and confirm every explicit ask shipped. Any miss blocks `phase: complete`.

## Hard rules

- "Plan means stop" — if the user said "plan X" or "design X", present at PLAN and STOP.
- Inline verification — every `[ ] → [x]` needs tool evidence.
- ID-stability — never re-number ISCs on edit.

See `.github/algorithm/ALGORITHM.md` for full doctrine.
