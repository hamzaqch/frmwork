---
mode: ask
description: Review recently changed code for simplification opportunities (preserves all functionality).
---

Read the recent diff (`git diff HEAD` if available, otherwise the file the user references).

Look for:

- **Redundancy** — repeated logic that can be extracted (only if it appears 3+ times)
- **Premature abstractions** — interfaces/factories with one implementation
- **Dead code** — unused exports, unused parameters, unreachable branches
- **Over-engineering** — error handling for impossible cases, fallbacks for unreachable failures
- **Comment rot** — comments describing WHAT (the code already shows that) or comments referencing past task IDs
- **Backwards-compat shims** for removed features that nobody calls anymore

Produce a punch-list:

```
SIMPLIFY:
  - <file>:<line> — <what to remove or simplify> — <why safe>
KEEP AS-IS:
  - <file>:<line> — <looked simplifiable but is load-bearing because Y>
```

**Hard rule:** never propose a simplification that changes behavior. Style and structure only.
