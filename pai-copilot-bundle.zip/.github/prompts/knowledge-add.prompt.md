---
mode: agent
description: Create a typed knowledge note in MEMORY/KNOWLEDGE/ with mandatory cross-links.
---

Type: ${input:type:idea | person | company | research}
Title: ${input:title}
Slug: ${input:slug:kebab-case-slug}

Workflow:

1. Determine target directory by `${type}`:
   - `idea` → `MEMORY/KNOWLEDGE/Ideas/`
   - `person` → `MEMORY/KNOWLEDGE/People/`
   - `company` → `MEMORY/KNOWLEDGE/Companies/`
   - `research` → `MEMORY/KNOWLEDGE/Research/`
2. Search existing notes for plausible cross-links — the new note MUST have at least one entry in `related:`.
3. Ask the user: "What does this connect to?" — propose candidates from search, accept user picks.
4. Write `<dir>/${slug}.md` with frontmatter per `.github/instructions/knowledge-format.instructions.md` and 3-section body (Summary, Detail, Cross-links).
5. For each `related:` entry, optionally edit the linked note's `related:` to make the cross-link bidirectional (ask user first).

Confirm: `Knowledge note created: <path>. Cross-links: <count>.`
