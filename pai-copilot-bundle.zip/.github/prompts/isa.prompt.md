---
mode: ask
description: Show or update the active ISA.
---

Read `MEMORY/WORK/work.json` to find the active ISA slug. Then read `MEMORY/WORK/{slug}/ISA.md`.

Report:

```
ISA: <slug>
Phase: <phase>
Progress: <M>/<N>
Goal: <one line>
Criteria pending: <count of [ ]>
Criteria passed: <count of [x]>
Last decision: <last entry in ## Decisions>
Next action: <first [ ] ISC>
```

If the user provides additional input (e.g., "add criterion X"), append to `## Criteria` with the next sequential ID. Never re-number existing IDs.
