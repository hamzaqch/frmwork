---
mode: agent
description: Advance the active ISA to the named phase.
---

Phase: ${input:phase:OBSERVE | THINK | PLAN | BUILD | EXECUTE | VERIFY | LEARN | COMPLETE}

1. Read `MEMORY/WORK/work.json` to find the active slug.
2. Read `MEMORY/WORK/{slug}/ISA.md` and verify the requested transition is valid (no skipping unless effort=quick).
3. Edit frontmatter `phase: ${phase}` and `updated: <now ISO 8601 UTC>`.
4. The PostToolUse hook syncs `work.json`.
5. Run any phase-entry actions:
   - **THINK** — write `## Risks`, `## Decisions` premortem entries
   - **PLAN** — write `## Features` table; STOP if user said "plan only"
   - **VERIFY** — run re-read check
   - **COMPLETE** — confirm all `[x]` have `## Verification` entries

Confirm: `Phase advanced: ${phase}. Progress: <M>/<N>.`
