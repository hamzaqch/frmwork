---
mode: ask
description: Explicit handoff to a named agent.
---

Target: ${input:agent:Agent name (e.g. engineer, reviewer, data-analyst)}

Verify `${agent}` is in the current agent's `handoffs:` list. If not, refuse with `Cannot handoff to ${agent} — not in handoffs list. Use /create-pai-agent or update handoffs in the current agent file.`

Otherwise: produce a one-line summary of the current state (active ISA slug, phase, last action) and pass control to `@${agent}`.
