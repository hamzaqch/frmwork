---
mode: agent
description: Run a Databricks query through the data-analyst agent (uses the databricks MCP).
---

Query: ${input:query:What do you want to know about the data?}

Hand off to `data-analyst` (or invoke its workflow inline).

Required behavior:

1. If catalog/schema/table is unknown — discover via `databricks/list_catalogs`, `list_schemas`, `list_tables`.
2. Quote the table schema before constructing SQL.
3. SQL must be SELECT-only. The MCP enforces this; you also must not propose mutations through this command.
4. Ask for `warehouse_id` if not in session memory.
5. Run `databricks/query_sql {warehouse_id, sql}`. Quote the JSON result.

For mutations (INSERT/UPDATE/DELETE/DROP/TRUNCATE/ALTER): tell the user to use `databricks` CLI directly with explicit confirmation — never through this command.
