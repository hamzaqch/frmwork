---
mode: ask
description: 3-pass search across MEMORY/KNOWLEDGE/ — lexical, frontmatter, wikilinks.
---

Query: ${input:query}

Run three passes:

1. **Lexical** — `Select-String -Pattern "${query}" -Path MEMORY/KNOWLEDGE/**/*.md` (or `rg`). Return file paths and matching lines.
2. **Frontmatter** — match `${query}` against `title:`, `tags:`, `type:` fields.
3. **Wikilinks** — find notes that contain `[[${query}]]` or that `${query}.md` itself references.

Combine results, dedupe, rank by:

1. Title exact match (highest)
2. Frontmatter tag match
3. Body lexical match
4. Wikilink-graph proximity (notes 1 hop away from a tag match)

Output:

```
HITS: <count>
1. [<title>](<path>) — <type> — <one-line summary from body>
2. ...
```

If 0 hits: surface the query terms used and suggest tag candidates.
