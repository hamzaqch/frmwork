---
mode: agent
description: Scaffold a new ISA file under MEMORY/WORK/{slug}/.
---

Slug: ${input:slug:Kebab-case slug for this task}
Title: ${input:title:Human-readable title}
Effort: ${input:effort:quick | standard | extended}

Create directory `MEMORY/WORK/${slug}/`.

Write `MEMORY/WORK/${slug}/ISA.md` with this frontmatter:

```yaml
---
slug: ${slug}
title: ${title}
phase: OBSERVE
effort: ${effort}
progress: 0/0
created: <today's ISO 8601 UTC>
updated: <today's ISO 8601 UTC>
---
```

Then add sections per effort tier (see `.github/instructions/isa-format.instructions.md`):

- Quick: Goal, Criteria
- Standard: + Problem, Test Strategy
- Extended: + Vision, Out of Scope, Principles, Constraints, Features, Decisions

After writing, update `MEMORY/WORK/work.json` (the `isa_sync.py` PostToolUse hook does this automatically; if you skip the hook, write manually).

Confirm: `ISA scaffolded: MEMORY/WORK/${slug}/ISA.md (phase: OBSERVE, effort: ${effort})`.
