# ISC — Implementation Success Criteria

## Format

```
- [ ] ISC-N: <criterion text>
- [x] ISC-N: <criterion text>           # passed, evidence in ## Verification
- [DEFERRED-VERIFY] ISC-N: <criterion>  # passed in code; live probe impossible — needs follow-up
```

IDs never re-number on edit. Splits become `ISC-N.M`. Drops become tombstones (`[ ] ISC-N: [DROPPED — see Decisions]`).

## Granularity test

Apply to every criterion as you write it:

| Test | Split when... |
|------|---------------|
| "And"/"With" | Joins two verifiable things |
| Independent failure | Part A can pass while B fails |
| Scope words | "all", "every", "complete" → enumerate |
| Domain boundary | Crosses UI/API/data/logic → one per boundary |
| **No nameable probe** | You cannot say which tool would verify it |

## Required prefixes

- **Anti-criterion** — `Anti: <what must NOT happen>` — at least 1 required.
- **Antecedent** — `Antecedent: <precondition>` — required when goal is experiential.

## Examples

**Bad (not granular):**
- [ ] ISC-1: All endpoints work and the UI looks good

**Good (split + atomic):**
- [ ] ISC-1: `GET /api/users` returns 200 with `[{id, name}]` shape — `curl` probe.
- [ ] ISC-2: `POST /api/users` returns 201 + Location header — `curl -i` probe.
- [ ] ISC-3: `/users` page renders user list at `<ul#users>` — Read DOM via VSCode preview.
- [ ] ISC-4: Anti: No 500 errors in browser console for 30s of normal use.

## Verification entry format

In `## Verification`:

```
ISC-3: Read .github/copilot-instructions.md — line 1 matches "# Project DA — Routing Doctrine"
ISC-12: Bash `python .github/scripts/security_pipeline.py < probe-input.json` — exit 2, stderr "BLOCKED: drive format"
```
