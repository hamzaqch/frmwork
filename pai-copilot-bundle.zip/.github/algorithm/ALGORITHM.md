# The Algorithm — 7-phase doctrine

> Adapted from PAI Algorithm v6.3.0 for GitHub Copilot. Same doctrine, smaller surface.

## Core idea

Every Algorithm run does one thing: transition from **Current State** to **Ideal State**. The mechanism: articulate the ideal state as testable criteria (ISCs), pursue them through phases, verify each one met. Iteration on the work IS iteration on the ISA (`MEMORY/WORK/{slug}/ISA.md`).

## When to enter Algorithm mode

- Multi-step work (>3 distinct subtasks)
- Cross-file refactor or migration
- New feature build
- Anything ambiguous, anything affecting `.github/` doctrine
- Explicit `/algo` slash command

For trivial single-file edits or a single command run, **skip the Algorithm** — answer directly.

## Effort tiers

| Tier | Budget | Required ISA sections | When |
|------|--------|----------------------|------|
| Quick | <5 min | Goal, Criteria | Trivial multi-step task |
| Standard | <20 min | Problem, Goal, Criteria, Test Strategy | Single-domain work |
| Extended | <60 min | + Vision, Out of Scope, Constraints, Features | Multi-file substantial work |

## Phases

### 1. OBSERVE 👁️

- **Intent echo** — restate the user's request in one sentence. If you cannot, re-read.
- **Reverse engineer** — explicit wants, explicit not-wanted, implied not-wanted, urgency.
- **Reproduce-first** — for any reported bug, reproduce the failure (curl, Read the file, run the command) BEFORE reading suspect code.
- **Scaffold ISA** — `MEMORY/WORK/{slug}/ISA.md` with the twelve sections (see `.github/instructions/isa-format.instructions.md`). Use `/isa-new` slash command.
- **Build ISCs** — atomic, each one a single binary tool probe (Read / Grep / Bash / curl / SELECT / `interceptor`-style screenshot). Split until granular.

### 2. THINK 🧠

- Riskiest assumptions, premortem, prerequisites.
- Refine ISCs based on premortem failure modes.
- Predict euphoric surprise: if every ISC passes, what will the user instantly recognize as true that they couldn't have predicted?

### 3. PLAN 📋

- Deliverable manifest — enumerate every sub-task the user explicitly asked for, numbered.
- Each deliverable maps to ≥1 ISC.
- Identify parallelizable work.
- For Standard+ effort, populate `## Features` with `name | satisfies | depends_on | parallelizable`.
- **STOP if user said "create a plan" or "design X"** — present and wait for approval before BUILD.

### 4. BUILD 🔨

- Spin up necessary tools, agents (via `/handoff`), MCP servers.
- For UI/page bugs: open the page first (the Reproduce-first rule).

### 5. EXECUTE ⚡

- Do the work. As each criterion passes, IMMEDIATELY tick `[ ]` → `[x]` and update `progress:`.
- Inline verification mandate — no `[x]` without evidence captured in the same or next tool call:
  - File write → Read it back
  - Code edit → Grep for the new symbol
  - Command run → checked output
  - HTTP/API → `curl -i` with status + body shape
  - DB change → `SELECT` confirming the migration

### 6. VERIFY ✅

- Re-check every `[x]` has tool-verified evidence in `## Verification`.
- For user-facing artifacts (web pages, deployed services), live-probe — not "should work."
- **Re-read check** — re-read the user's last message verbatim and enumerate every explicit ask against what shipped. Any miss blocks `phase: complete`.

### 7. LEARN 📚

- What should I have done differently?
- What would a smarter algorithm have done?
- Did the Verification mandate catch anything?
- Append to `MEMORY/LEARNING/sessions.jsonl` if the Stop hook hasn't already.

## Forbidden language

`"should work"`, `"should be"`, `"expected to"`, `"the change is in place"` (without Read/Grep), `"done"` (without tool evidence), `"no errors"` (without the actual log).

## ISC granularity rule

> Split until each criterion is one binary tool probe. If you cannot name the probe, the criterion is not yet atomic.

See `.github/algorithm/ISC.md` for examples.
