"""Shared helpers for PAI hook scripts.

All hook scripts read JSON from stdin, do their work, and print JSON to stdout.
Exit 2 + stderr message = hard block (Copilot lifecycle convention, mirrored from Claude Code).
"""

from __future__ import annotations

import json
import os
import pathlib
import sys
import time

LOG_FILE = "MEMORY/LEARNING/hook-log.jsonl"


def read_input() -> dict:
    """Read and parse JSON from stdin. Returns {} if empty/invalid."""
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            return {}
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def repo_root() -> pathlib.Path:
    """Walk up from cwd until we find .github/. Fallback to cwd."""
    p = pathlib.Path(os.getcwd()).resolve()
    for candidate in [p, *p.parents]:
        if (candidate / ".github").is_dir():
            return candidate
    return p


def log(message: str, **fields) -> None:
    """Append a JSONL log line. Non-fatal on disk errors."""
    try:
        path = repo_root() / LOG_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        entry = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "msg": message, **fields}
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except (OSError, PermissionError):
        pass


def emit_continue() -> None:
    """Standard non-blocking hook response."""
    print(json.dumps({"continue": True}))


def emit_block(reason: str) -> None:
    """Hard block — exit 2 + stderr message.

    The Copilot Preview hook contract (mirrored from Claude Code) treats exit 2
    with stderr as a deny signal that surfaces to the user.
    """
    print(f"[PAI SECURITY] BLOCKED: {reason}", file=sys.stderr)
    sys.exit(2)


def emit_ask(reason: str) -> None:
    """Soft block — surface to user for explicit approval."""
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "ask",
            "permissionDecisionReason": reason,
        }
    }))
