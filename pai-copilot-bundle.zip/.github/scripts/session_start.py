"""SessionStart hook: print active ISA context if any.

Reads MEMORY/WORK/work.json and surfaces the most recently updated active session.
"""

from __future__ import annotations

import json

from _common import read_input, repo_root, emit_continue, log


def main() -> None:
    read_input()  # consume stdin
    registry_path = repo_root() / "MEMORY" / "WORK" / "work.json"
    if not registry_path.exists():
        log("session_start", state="no_active_isa")
        return

    try:
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        log("session_start", state="corrupt_registry")
        return

    sessions = registry.get("sessions", {})
    active = [
        (slug, meta) for slug, meta in sessions.items()
        if meta.get("phase") not in {"COMPLETE"}
    ]
    if not active:
        log("session_start", state="no_active")
        return

    active.sort(key=lambda kv: kv[1].get("updated", ""), reverse=True)
    slug, meta = active[0]
    log("session_start", active_slug=slug, phase=meta.get("phase"))


if __name__ == "__main__":
    try:
        main()
    finally:
        emit_continue()
