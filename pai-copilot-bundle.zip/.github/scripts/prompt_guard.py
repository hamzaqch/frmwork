"""UserPromptSubmit hook: detect mode hints (/algo, /isa, etc.) and log.

Currently informational — does not modify the prompt. Logs the classification
for later analysis at MEMORY/LEARNING/hook-log.jsonl.
"""

from __future__ import annotations

from _common import read_input, emit_continue, log


ALGO_TRIGGERS = ("/algo", "/isa", "/isa-new", "/isa-phase", "/create-pai-agent")


def main() -> None:
    inp = read_input()
    prompt = (inp.get("prompt") or inp.get("user_prompt") or "").strip()
    classification = "general"
    for trigger in ALGO_TRIGGERS:
        if prompt.startswith(trigger):
            classification = trigger
            break
    log("prompt_submit", classification=classification, length=len(prompt))


if __name__ == "__main__":
    try:
        main()
    finally:
        emit_continue()
