"""Frontmatter parser. Stdlib only — no PyYAML dependency."""

from __future__ import annotations

import re

VALID_PHASES = {
    "OBSERVE", "THINK", "PLAN", "BUILD", "EXECUTE", "VERIFY", "LEARN", "COMPLETE",
}


def parse_frontmatter(text: str) -> dict | None:
    """Parse YAML-ish frontmatter. Returns None if no frontmatter found.

    Supports flat scalar fields only: `key: value`. Strips quotes.
    """
    match = re.match(r"^---\r?\n(.*?)\r?\n---", text, re.DOTALL)
    if not match:
        return None
    fm: dict[str, str] = {}
    for line in match.group(1).splitlines():
        if ":" not in line or line.startswith("#"):
            continue
        key, _, value = line.partition(":")
        fm[key.strip()] = value.strip().strip("'\"")
    return fm


def normalize_phase(value: str | None) -> str:
    """Return uppercase phase if valid, else fall back to OBSERVE."""
    if not value:
        return "OBSERVE"
    upper = value.upper()
    return upper if upper in VALID_PHASES else "OBSERVE"
