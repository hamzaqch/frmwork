"""Stop hook: append session summary to MEMORY/LEARNING/sessions.jsonl."""

from __future__ import annotations

import datetime
import json

from _common import read_input, repo_root, emit_continue, log


def main() -> None:
    inp = read_input()
    session_id = inp.get("session_id", "unknown")
    entry = {
        "ts": datetime.datetime.utcnow().isoformat() + "Z",
        "session_id": session_id,
        "tool_calls": inp.get("tool_call_count"),
        "messages": inp.get("message_count"),
    }
    path = repo_root() / "MEMORY" / "LEARNING" / "sessions.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
    log("stop", session_id=session_id)


if __name__ == "__main__":
    try:
        main()
    finally:
        emit_continue()
