"""PreToolUse hook: deny | ask | allow.

Stdin: JSON {session_id, tool_name, tool_input: {command?, file_path?, ...}}
Output:
  - exit 2 + stderr "BLOCKED: ..." for hard deny
  - stdout JSON with permissionDecision="ask" for soft block
  - stdout JSON {"continue": true} for allow

Inspectors run in order: hard-deny patterns → ask patterns → allow.
"""

from __future__ import annotations

import re

from _common import read_input, emit_continue, emit_block, emit_ask, log


HARD_DENY = [
    (re.compile(r"\bRemove-Item\b.*-Recurse\b.*-Force\b.*[A-Za-z]:\\\\?(?:\s|$)"), "rm -rf at drive root"),
    (re.compile(r"\bformat\s+[A-Za-z]:"), "drive format"),
    (re.compile(r"\bgit\s+push\s+.*--force(?!-with-lease)"), "destructive force-push"),
    (re.compile(r"\bdatabricks\s+(workspace|fs)\s+rm\s+.*--recursive"), "databricks recursive delete"),
    (re.compile(r"(?:Remove-Item|del|erase)\s+.*\\Windows\\\\?"), "system directory delete"),
    (re.compile(r"\b(?:cat|type|Get-Content)\s+.*\.env"), "secret file read"),
    (re.compile(r"\b(?:cat|type|Get-Content)\s+.*id_rsa"), "ssh key read"),
]

ASK = [
    (re.compile(r"\bdatabricks\s+sql\s+.*\b(DELETE|DROP|TRUNCATE|ALTER|MERGE)\b", re.IGNORECASE),
     "destructive SQL — confirm target catalog.schema.table"),
    (re.compile(r"\bgit\s+reset\s+--hard\b"), "git reset --hard discards uncommitted changes"),
    (re.compile(r"\bgit\s+clean\s+-fd\b"), "git clean -fd deletes untracked files"),
    (re.compile(r"\bnpm\s+install\b"), "use bun, not npm — confirm if intentional"),
]


def extract_target(tool_input) -> str:
    if not isinstance(tool_input, dict):
        return str(tool_input or "")
    parts = [
        str(tool_input.get("command", "")),
        str(tool_input.get("file_path", "")),
        str(tool_input.get("content", ""))[:200],
    ]
    return " ".join(parts)


def main() -> None:
    inp = read_input()
    target = extract_target(inp.get("tool_input"))

    for pattern, reason in HARD_DENY:
        if pattern.search(target):
            log("hard_deny", reason=reason, target=target[:120])
            emit_block(reason)

    for pattern, reason in ASK:
        if pattern.search(target):
            log("ask", reason=reason, target=target[:120])
            emit_ask(reason)
            return

    emit_continue()


if __name__ == "__main__":
    main()
