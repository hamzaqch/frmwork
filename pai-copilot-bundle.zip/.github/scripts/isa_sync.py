"""PostToolUse hook: when an ISA.md is edited, sync frontmatter to MEMORY/WORK/work.json.

Stdin: JSON {session_id, tool_name, tool_input: {file_path, ...}}
Stdout: {"continue": true}
Exit 0 — read-only sync, never blocks.
"""

from __future__ import annotations

import datetime
import json
import pathlib

from _common import read_input, repo_root, emit_continue, log
from isa_utils import parse_frontmatter, normalize_phase


def main() -> None:
    inp = read_input()
    file_path = (inp.get("tool_input") or {}).get("file_path", "")
    normalized = file_path.replace("\\", "/")
    if "MEMORY/WORK/" not in normalized or not normalized.endswith("ISA.md"):
        return

    isa_path = pathlib.Path(file_path)
    if not isa_path.exists():
        return

    fm = parse_frontmatter(isa_path.read_text(encoding="utf-8")) or {}
    slug = fm.get("slug")
    if not slug:
        return

    root = repo_root()
    registry_path = root / "MEMORY" / "WORK" / "work.json"
    registry_path.parent.mkdir(parents=True, exist_ok=True)

    if registry_path.exists():
        try:
            registry = json.loads(registry_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            registry = {"sessions": {}}
    else:
        registry = {"sessions": {}}

    registry.setdefault("sessions", {})
    try:
        relative_path = str(isa_path.resolve().relative_to(root))
    except ValueError:
        relative_path = str(isa_path)

    registry["sessions"][slug] = {
        "phase": normalize_phase(fm.get("phase")),
        "title": fm.get("title", slug),
        "effort": fm.get("effort", "standard"),
        "progress": fm.get("progress", "0/0"),
        "isa_path": relative_path.replace("\\", "/"),
        "updated": datetime.datetime.utcnow().isoformat() + "Z",
    }

    registry_path.write_text(json.dumps(registry, indent=2) + "\n", encoding="utf-8")
    log("isa_sync", slug=slug, phase=registry["sessions"][slug]["phase"])


if __name__ == "__main__":
    try:
        main()
    finally:
        emit_continue()
