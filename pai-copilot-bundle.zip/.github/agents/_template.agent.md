---
name: TEMPLATE_NAME
description: ONE_SENTENCE_PURPOSE
model: claude-opus-4.6
tools: [codebase, editFiles]
handoffs: [principal]
---

# TEMPLATE_NAME

## Identity

ONE_PARAGRAPH_IDENTITY

## When to invoke

- TRIGGER_PHRASE_1
- TRIGGER_PHRASE_2
- TRIGGER_PHRASE_3

## Workflow

1. STEP_1
2. STEP_2
3. STEP_3

## Hard rules

- DENY_RULE_1
- DENY_RULE_2

## Output format

OUTPUT_FORMAT_DESCRIPTION

## Voice

VOICE_TONE
