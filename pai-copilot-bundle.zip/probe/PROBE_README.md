# Hook Contract Probe

Use this BEFORE relying on `.github/scripts/security_pipeline.py` or `isa_sync.py` as load-bearing enforcement. The Copilot Preview hook contract is documented but not yet rock-stable; capture the actual contract from your environment first.

## Steps

1. **Copy the probe**

   ```powershell
   Copy-Item probe\probe_hook.py .github\scripts\probe_hook.py -Force
   ```

2. **Wire it into hooks.json temporarily**. Add this entry, leave existing hooks alone:

   ```jsonc
   "PreToolUse": [
     {
       "matcher": ["editFiles", "terminal", "runCommands", "*"],
       "command": "python",
       "args": [".github/scripts/probe_hook.py"]
     }
   ]
   ```

   Add similar entries under `PostToolUse`, `UserPromptSubmit`, `SessionStart`, `Stop`.

3. **Reload VSCode** (`Ctrl+Shift+P` → "Developer: Reload Window").

4. **Run 5 representative actions in chat:**

   - Ask the agent to read a file (`@principal show me README.md`)
   - Ask the agent to edit a file (`@engineer add a comment to <file>`)
   - Ask the agent to run a terminal command (`@engineer run python --version`)
   - Trigger a UserPromptSubmit (any chat message)
   - End the session and reopen

5. **Read the log:**

   ```powershell
   Get-Content probe\probe-log.jsonl
   ```

6. **Verify against assumptions:**

   | Assumption | What to check in the log |
   |-----------|--------------------------|
   | stdin is JSON | `parsed_stdin` is non-null and an object |
   | Has `tool_name` field | look for `"tool_name"` in raw or parsed |
   | Has `tool_input` field | look for `"tool_input"` |
   | Has `tool_input.command` for shell calls | look at parsed_stdin for terminal entries |
   | Has `tool_input.file_path` for edits | look at parsed_stdin for editFiles entries |
   | Matcher names | The action you took mapped to which `tool_name`? |

7. **Restore hooks.json** — remove the probe entries, keep only the real hooks.

8. **Adjust security_pipeline.py / isa_sync.py if needed:**

   - If `tool_name` is e.g. `"shell"` instead of `"terminal"` → update `matcher` arrays in `hooks.json`.
   - If `tool_input` has a different shape → update `extract_target()` in `security_pipeline.py` and the file_path parse in `isa_sync.py`.

## Expected output (best guess based on Claude Code parity)

Each `probe-log.jsonl` line should look approximately:

```json
{
  "ts": "2026-05-09T...",
  "raw_stdin": "{\"session_id\":\"...\",\"tool_name\":\"editFiles\",\"tool_input\":{\"file_path\":\"...\",\"content\":\"...\"}}",
  "parsed_stdin": {
    "session_id": "...",
    "tool_name": "editFiles",
    "tool_input": {"file_path": "...", "content": "..."}
  },
  "env_keys": ["COPILOT_..."],
  "argv": [".github/scripts/probe_hook.py"],
  "cwd": "C:\\path\\to\\repo"
}
```

If the actual shape differs materially — surface to me with a few sample lines and I'll update the scripts.
