"""Probe hook — captures stdin contract for verification before relying on full hooks.

Drop this into a temporary `.github/hooks/probe.json` registration (or replace one
of the real hook entries) to capture what Copilot actually sends. Run a few tool
calls in VSCode, then read the output log and compare against assumptions.

Output: appends each invocation to `probe/probe-log.jsonl` with raw stdin,
timestamp, env hints, and the response we returned.

Always returns {"continue": true} — never blocks. Read-only telemetry.
"""

from __future__ import annotations

import datetime
import json
import os
import pathlib
import sys


def main() -> None:
    raw = sys.stdin.read()
    try:
        parsed: object = json.loads(raw) if raw.strip() else None
    except json.JSONDecodeError:
        parsed = None

    entry = {
        "ts": datetime.datetime.utcnow().isoformat() + "Z",
        "raw_stdin": raw,
        "parsed_stdin": parsed,
        "env_keys": sorted(k for k in os.environ if k.startswith(("COPILOT_", "VSCODE_", "GH_"))),
        "argv": sys.argv,
        "cwd": os.getcwd(),
    }

    log_path = pathlib.Path("probe") / "probe-log.jsonl"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


if __name__ == "__main__":
    try:
        main()
    finally:
        print(json.dumps({"continue": True}))
