# Knowledge Index

Typed entity graph. Every note has frontmatter + at least one cross-link. See `.github/instructions/knowledge-format.instructions.md` for the contract.

## Categories

| Type | Path | Purpose |
|------|------|---------|
| Idea | `Ideas/` | Concepts, theories, frameworks |
| Person | `People/` | Individuals, roles |
| Company | `Companies/` | Organizations, products |
| Research | `Research/` | Findings from external lookups |

## Search

Run `/knowledge-search <query>` for a 3-pass lookup (lexical, frontmatter, wikilinks).

## Add

Run `/knowledge-add` to scaffold a new note with mandatory cross-links.

## Notes

Currently empty. Notes accumulate as work generates reusable insights — orphan notes (no `related:` cross-links) are rejected.
