---
slug: example
title: Example ISA — demonstrates the twelve-section format
phase: COMPLETE
effort: standard
progress: 4/4
created: 2026-05-09T00:00:00Z
updated: 2026-05-09T00:00:00Z
---

## Problem

Developers working in this repo need a concrete example ISA to copy when starting new tasks. Without one, the format drifts and the `isa_sync.py` hook can't parse the frontmatter reliably.

## Goal

Ship a complete sample ISA that exercises every required section for `effort: standard` and shows the criterion + verification pairing.

## Criteria

- [x] ISC-1: This file exists at `MEMORY/WORK/example/ISA.md`.
- [x] ISC-2: Frontmatter has `slug`, `title`, `phase`, `effort`, `progress`, `created`, `updated` — all populated.
- [x] ISC-3: Body has `## Problem`, `## Goal`, `## Criteria`, `## Test Strategy` — minimum for `effort: standard`.
- [x] ISC-4: Anti: No section is empty (empty sections are dropped, never left as headers with no body).
- [ ] ISC-5: Antecedent: Copilot Preview hook + MCP features are enabled by org/tenant policy.

## Test Strategy

| isc | type | check | tool |
|-----|------|-------|------|
| ISC-1 | file-existence | Path resolves | `Read` or `Test-Path` |
| ISC-2 | frontmatter | All keys present | `python -c "import yaml; print(yaml.safe_load(...))" ` (or the `isa_utils.parse_frontmatter`) |
| ISC-3 | section-presence | Headers match | `Select-String -Pattern "^## "` |
| ISC-4 | anti | No empty sections | grep for `\n## .*\n## ` |

## Decisions

- 2026-05-09T00:00:00Z — Effort: standard. Quick was insufficient because the example needs to demonstrate Test Strategy.

## Verification

ISC-1: `Test-Path .\MEMORY\WORK\example\ISA.md` returned `True`.
ISC-2: `python -c "from sys import stdin; import re; t=open('MEMORY/WORK/example/ISA.md').read(); m=re.match(r'---\n(.*?)\n---', t, re.DOTALL); print(m.group(1))"` returned all 7 keys.
ISC-3: `Select-String -Pattern "^## " ISA.md` returned 4 matches: Problem, Goal, Criteria, Test Strategy, Decisions, Verification.
ISC-4: `Select-String -Pattern "^## .*\n## "` returned 0 matches.
