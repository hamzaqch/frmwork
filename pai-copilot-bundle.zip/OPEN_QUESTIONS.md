# Open Questions — verify in your environment before relying on these assumptions

These are the things I assumed when generating this bundle. Verify each one with a small probe in your VSCode + Copilot setup before treating the bundle as production-ready.

## 1. Hook stdin/stdout contract

**Assumed:** Stdin is JSON `{session_id, tool_name, tool_input}`. Hooks return `{"continue": true}` to allow, exit 2 + stderr to hard-block, or stdout JSON `{"hookSpecificOutput": {"permissionDecision": "ask", ...}}` to soft-block.

**Risk if wrong:** `security_pipeline.py` is decorative. The instructions-mirror in `security-rules.instructions.md` becomes the only enforcement.

**Verify:** Run the probe (see `probe/PROBE_README.md`). Compare actual log against the assumed shape.

## 2. Tool matcher names

**Assumed:** `editFiles`, `terminal`, `runCommands` are valid `matcher:` array entries in `hooks.json`. Any of these triggers PreToolUse for the relevant action.

**Risk if wrong:** Hooks don't fire on the actions you expect. Security and ISA sync silently miss.

**Verify:** From the probe log, see what `tool_name` Copilot actually sends for each action. Update `matcher` arrays accordingly.

## 3. `model:` field per agent

**Assumed:** `model: claude-opus-4.6` in agent frontmatter is honored — each agent can pin to a specific model.

**Risk if wrong:** Copilot uses whatever the user has selected in the Copilot dropdown, ignoring per-agent specification.

**Verify:** Set one agent to a different model (e.g. `claude-sonnet-4.6`), invoke it, ask "what model are you?" — see if the answer differs from the dropdown.

**Mitigation if not honored:** Drop the `model:` field everywhere. Document in README that the model selection is a Copilot UI setting, not a per-agent property.

## 4. Hot-reload scope

**Assumed:** `.github/agents/`, `.github/instructions/`, `.github/prompts/` reload on save (no VSCode restart). `hooks.json` and `mcp.json` require window reload.

**Risk if wrong:** Either (a) you waste time reloading the window when not needed, or (b) you skip a reload and the bundle silently runs stale.

**Verify:** Edit one of each file type, observe whether changes take effect immediately or require reload. Document the result in this file.

## 5. Databricks CLI auth flow

**Assumed:** `databricks` CLI is pre-authenticated with a default profile. The MCP server shells out and gets results.

**Risk if wrong:** First MCP call hangs while CLI initiates browser auth. Stdio MCP doesn't surface the auth prompt.

**Verify:** Run `databricks catalogs list --output json` in PowerShell — if it returns immediately, you're authenticated. If it opens a browser, complete auth before launching VSCode.

## 6. `work.json` race conditions

**Assumed:** Multiple PostToolUse hooks fire serially, not concurrently. Naive read-modify-write on `work.json` is safe.

**Risk if wrong:** Two hooks racing → one slug entry clobbered.

**Verify:** Hard to reproduce manually. If you observe missing slugs in `work.json`, switch to per-slug files: `MEMORY/WORK/_state/{slug}.json` (one file per session, no shared write).

## 7. `applyTo:` glob behavior

**Assumed:** Frontmatter `applyTo: "MEMORY/WORK/**/ISA.md"` causes `isa-format.instructions.md` to load only when the conversation context is touching files matching that glob.

**Risk if wrong:** Either (a) the instruction is always loaded (token bloat) or (b) it's never loaded (model doesn't know the format).

**Verify:** Open a non-ISA file in chat context. Ask the model to describe ISA frontmatter. If it knows → instruction is always loaded. If it doesn't → glob is working as expected.

## 8. Sandbox absence on Windows

**Assumed:** MCP servers run unsandboxed on Windows. There's no `sandbox:` field in `mcp.json` to set.

**Risk if wrong:** None — sandbox absence is documented Copilot behavior. But it means the Databricks MCP server is trusted code; treat it accordingly.

**Verify:** Confirmed in research. Document for any future contributors that they cannot rely on sandbox isolation.

## 9. PowerShell vs Python for hooks

**Decision:** Python chosen over PowerShell. Reasoning: hook scripts share helpers (frontmatter parsing, JSON, regex), and Python has all of these in stdlib. PowerShell would need `ConvertFrom-Json` plus regex modules and gets verbose fast.

**If you'd prefer PowerShell:** ask for a PowerShell port. The `hooks.json` change is small (`"command": "pwsh"`, `"args": [".github/scripts/isa_sync.ps1"]`); the script logic translates 1:1.

## 10. Org / tenant policy

**Risk:** Workplace org admins can disable Copilot Preview features (hooks) and/or MCP servers entirely via tenant policy. Phase 2 + Phase 3 silently produce no effect if disabled.

**Verify before Phase 2/3 use:**

- `Settings > Copilot > Advanced > Hooks` (or equivalent in your version) — confirm enabled.
- Try invoking the `databricks` MCP from chat (`@data-analyst list catalogs`); a "MCP servers disabled by policy" error indicates tenant restriction.

**Mitigation if disabled:** Phase 1 (instructions / agents / prompts) still works without hooks or MCP. Use `security-rules.instructions.md` as instructions-only enforcement and ask the user to run `databricks` CLI commands directly in the integrated terminal.

## 11. `handoffs:` frontmatter is PAI convention, not Copilot-honored

**Clarification:** Copilot reads `.agent.md` frontmatter for `name`, `description`, `model`, `tools` — those drive behavior. `handoffs:` is a PAI convention that the model reads as prose; it does NOT produce deterministic routing.

**Practical impact:** "Routing" is an `@agent-name` invocation by the user (or by the calling agent's text). The `handoffs:` list is documentation of allowed transitions, not enforcement.

**If you want deterministic enforcement:** add a hook (PostToolUse on `editFiles` of agent files) that validates handoff lists before agent activation. Out of scope for v1.

## 12. `work.json` atomic write on Windows

**Clarification:** `pathlib.Path.write_text()` (used in `isa_sync.py`) is NOT atomic on Windows when a reader holds the file open — Windows file locking can intermittently fail the write.

**Mitigation:** If you observe corrupted `work.json`, switch `isa_sync.py` to `os.replace(tmp_path, target)` after writing to a sibling temp file. `os.replace()` is atomic on the same volume.

**Future:** Consider switching to one file per slug under `MEMORY/WORK/_state/{slug}.json` — eliminates contention entirely.

## 13. `copilot-instructions.md` size budget

**Risk:** Historically Copilot truncates `copilot-instructions.md` past ~32 KB. Routing doctrine + Windows-shell rule + skill index can push past it.

**Current bundle:** `copilot-instructions.md` is ~50 lines / ~2 KB — well under any practical cap. But if you add to it, watch the size.

**Mitigation:** Keep `copilot-instructions.md` focused on routing only. Push detail into `.github/instructions/*.instructions.md` files with `applyTo:` globs — those load only when relevant context appears.

## 14. Single project vs reusable framework

**Decision:** Single project's `.github/`. Iterate before promoting to a reusable repo.

**Trigger to promote:** When you've used the bundle on 2+ projects and the agent/skill set has stabilized (no edits for 2 weeks).

**Promotion path:** Create `pai-copilot-framework` repo. Move `.github/{agents,instructions,prompts,skills,algorithm}/` and `.vscode/mcp-servers/databricks_mcp.py` into it. Each project's `.github/` becomes a thin overlay (project-specific copilot-instructions.md, project-specific agents).
